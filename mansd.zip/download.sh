wget https://github.com/Kamakepar2029/ltcbot_kamakepar/raw/main/install.sh
cat install.sh | bash