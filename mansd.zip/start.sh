pip3 install telethon flask colorama requests bs4 pyaes
python3 bots.py