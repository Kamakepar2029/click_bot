apt install python3 python3-pip -y
apt install python python-pip -y
git clone https://github.com/Kamakepar2029/ltcbot_kamakepar
cd ltcbot_kamakepar
bash start.sh
cd ..
echo "To start telebot, type: python3 bots.py +*************"